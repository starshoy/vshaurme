from django.apps import AppConfig


class LoggginConfig(AppConfig):
    name = 'registration'
